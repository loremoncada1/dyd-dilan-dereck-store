document.addEventListener("DOMContentLoaded", () => {
    const productos = [
        { nombre: "Producto 1", precio: "$10" },
        { nombre: "Producto 2", precio: "$15" }
    ];
    const lista = document.getElementById("lista-productos");
    productos.forEach(p => {
        const div = document.createElement("div");
        div.textContent = `${p.nombre} - ${p.precio}`;
        lista.appendChild(div);
    });
});